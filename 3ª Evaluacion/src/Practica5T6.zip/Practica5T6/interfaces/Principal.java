package interfaces;

public class Principal {
		
	public static void main(String[] args) {
	Ventana2 chef=new Ventana2();

	chef.setVisible(true);
}
}