package Eventos;

import javax.swing.JFrame;

public class Copiado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Metodo form =new Metodo();
		form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
